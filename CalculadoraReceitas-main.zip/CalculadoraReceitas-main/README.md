Explicação do programa:
Primeiramente ele pega o link da área de trabalho do usuário e combina o caminho com o Nome do arquivo para assim gerar o caminho para ser acessado pelo documento txt. É feita uma verificação se o programa existe e se ele não exisitr, é criado um. 

Após isso é feito a leitura do arquivo usando como divisão o ';' podendo ser possivel identificar se é uma receita pelo RCT e se é um ingrediente pelo ING. Continuamente é feito a leitura(se for receita, le o nome e o preço) (Se for ingrediente, le o nome, quantidade e a unidade de medida)

Após a leitura é possivel fazer o carregamento do menu de opções podendo a pessoa preparar alguma receita, ver as receitas ja adicionadas, remover alguma receita e por fim sair do programa

ADICIONAR
O programa pergunta inicialmente o nome da receita e para quantas pessoas ela é feita, por seguinte é feito o cadastro dos ingredientes em uma lista e por fim é perguntado o preço.
A pergunta do numero de pessoas é algo importante devido a todos os valores do ingredientes serem divididos pela mesma, a fim de obter os valores respectivos a uma pessoa

PREPARAR
É perguntado qual receita se quer preparar e para quantas pessoas serão
Após isso, é lido a quantidade utilizada para cada ingrediente para uma pessoa e é multiplicado pelo número de pessoas inserido

VER
Mostra todas as receitas ja inseridas, na ordem que foram inseridas

REMOVER
Remove a receita selecionada

SAIR
Sai do programa
